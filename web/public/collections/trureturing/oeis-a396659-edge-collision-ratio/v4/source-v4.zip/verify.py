import argparse
from collections import defaultdict
from fractions import Fraction
import json
from itertools import permutations, product
from math import factorial
from pathlib import Path


def edge_list(vertices):
    return tuple(zip(vertices, vertices[1:]))


def row_by_subsets(size):
    incident_vertices = [0] * (1 << (size * size))
    for mask in range(1, len(incident_vertices)):
        lowest_bit = mask & -mask
        edge_index = lowest_bit.bit_length() - 1
        tail, head = divmod(edge_index, size)
        incident_vertices[mask] = incident_vertices[mask ^ lowest_bit] | (1 << tail) | (1 << head)
    states = {(0, 0): 1}
    collisions = defaultdict(int)
    peak_states = 1
    full_vertex_mask = (1 << size) - 1
    for depth in range(size * size + 1):
        following = defaultdict(int)
        for (used, endpoint), multiplicity in states.items():
            for head in range(size):
                edge_bit = 1 << (endpoint * size + head)
                if used & edge_bit:
                    visited = incident_vertices[used] | 1 | (1 << head)
                    if visited == full_vertex_mask:
                        collisions[depth + 1] += multiplicity
                else:
                    following[(used | edge_bit, head)] += multiplicity
        if depth == size * size:
            euler_count = sum(states.values())
            assert all(endpoint == 0 for used, endpoint in states)
        states = following
        peak_states = max(peak_states, len(states))
    assert not states
    row = [collisions[length] for length in range(size + 1, size * size + 2)]
    if size >= 2:
        assert row[-2] == (2 * size - 1) * euler_count
        assert row[-1] == size * euler_count
        assert Fraction(row[-2], row[-1]) == Fraction(2 * size - 1, size)
    assert row[0] == factorial(size)
    assert row[-1] == factorial(size) ** size
    assert euler_count == factorial(size) ** size // size
    return {'n': size, 'row': row, 'euler_count': euler_count, 'peak_layer_states': peak_states}


def rooted_trees(size):
    nonroot = tuple(range(1, size))
    for choices in product(*(tuple(vertex for vertex in range(size) if vertex != tail)
                             for tail in nonroot)):
        parents = dict(zip(nonroot, choices))
        valid = True
        for vertex in nonroot:
            seen = set()
            current = vertex
            while current != 0:
                if current in seen:
                    valid = False
                    break
                seen.add(current)
                current = parents[current]
            if not valid:
                break
        if valid:
            yield parents


def last_exit_checks(size, eulers):
    generated = {}
    tree_count = 0
    for parents in rooted_trees(size):
        tree_count += 1
        options = [tuple(permutations(range(size)))]
        for vertex in range(1, size):
            options.append(tuple(order + (parents[vertex],)
                                 for order in permutations(tuple(head for head in range(size)
                                                                 if head != parents[vertex]))))
        for orders in product(*options):
            consumed = [0] * size
            walk = [0]
            while consumed[walk[-1]] < size:
                tail = walk[-1]
                head = orders[tail][consumed[tail]]
                consumed[tail] += 1
                walk.append(head)
            vertices = tuple(walk)
            assert len(vertices) == size * size + 1 and vertices[-1] == 0
            assert len(set(edge_list(vertices))) == size * size
            assert vertices not in generated
            recovered_orders = tuple(tuple(head for tail, head in edge_list(vertices)
                                           if tail == vertex) for vertex in range(size))
            assert recovered_orders == orders
            assert {vertex: recovered_orders[vertex][-1] for vertex in range(1, size)} == parents
            generated[vertices] = (parents, orders)
    assert set(generated) == eulers
    assert tree_count == size ** (size - 2)
    return {'n': size, 'rooted_trees': tree_count, 'local_order_data': len(generated),
            'euler_walks': len(eulers), 'both_directions_checked': True}


def pruefer_checks(size):
    seen_trees = set()
    for word in product(range(size), repeat=size - 2):
        degrees = [1 + word.count(vertex) for vertex in range(size)]
        edges = set()
        for parent in word:
            leaf = next(vertex for vertex in range(size) if degrees[vertex] == 1)
            edges.add(tuple(sorted((leaf, parent))))
            degrees[leaf] -= 1
            degrees[parent] -= 1
        final = tuple(vertex for vertex in range(size) if degrees[vertex] == 1)
        assert len(final) == 2
        edges.add(final)
        frozen = frozenset(edges)
        assert len(frozen) == size - 1 and frozen not in seen_trees
        seen_trees.add(frozen)
        remaining = set(edges)
        recovered = []
        for step in range(size - 2):
            leaf = next(vertex for vertex in range(size)
                        if sum(vertex in edge for edge in remaining) == 1)
            selected = next(edge for edge in remaining if leaf in edge)
            recovered.append(next(vertex for vertex in selected if vertex != leaf))
            remaining.remove(selected)
        assert tuple(recovered) == word
    assert len(seen_trees) == sum(1 for parents in rooted_trees(size)) == size ** (size - 2)
    return {'n': size, 'trees_and_words': len(seen_trees), 'both_directions_checked': True}


def trail_checks(size):
    full_edges = {(tail, head) for tail in range(size) for head in range(size)}
    eulers = set()
    almost_complete = []

    def extend(vertices, used):
        if len(used) == size * size - 1:
            almost_complete.append(vertices)
        if len(used) == size * size:
            eulers.add(vertices)
            return
        for head in range(size):
            edge = (vertices[-1], head)
            if edge not in used:
                extend(vertices + (head,), used | {edge})

    extend((0,), set())
    return_trails = set()
    missing_loops = defaultdict(set)
    short_collisions = set()
    for vertices in almost_complete:
        used = set(edge_list(vertices))
        missing = next(iter(full_edges - used))
        tail, head = missing
        endpoint = vertices[-1]
        assert set(vertices) == set(range(size))
        is_return = head == 0 and tail == endpoint
        is_other_loop = tail == head and tail != 0 and endpoint == 0
        assert is_return != is_other_loop
        if is_return:
            return_trails.add(vertices)
        else:
            missing_loops[tail].add(vertices)
        for next_vertex in range(size):
            if (endpoint, next_vertex) in used:
                short_collisions.add(vertices + (next_vertex,))
    completed_returns = {vertices + (0,) for vertices in return_trails}
    assert completed_returns == eulers
    assert {vertices[:-1] for vertices in eulers} == return_trails
    checks = []
    for vertex in range(1, size):
        marked_to_euler = {}
        for vertices in missing_loops[vertex]:
            cuts = [position for position, value in enumerate(vertices) if value == vertex]
            assert len(cuts) == size - 1
            for position in cuts:
                inserted = vertices[:position + 1] + (vertex,) + vertices[position + 1:]
                assert inserted not in marked_to_euler
                marked_to_euler[inserted] = (vertices, position)
        assert set(marked_to_euler) == eulers
        for vertices in eulers:
            position = edge_list(vertices).index((vertex, vertex))
            removed = vertices[:position + 1] + vertices[position + 2:]
            assert marked_to_euler[vertices] == (removed, position)
        checks.append({'vertex': vertex, 'missing_loop_trails': len(missing_loops[vertex]),
                       'marked_cuts': len(marked_to_euler)})
    long_collisions = {vertices + (head,) for vertices in eulers for head in range(size)}
    assert len(short_collisions) == (2 * size - 1) * len(eulers)
    assert len(long_collisions) == size * len(eulers)
    return {'n': size, 'almost_complete_trails': len(almost_complete),
            'return_trails': len(return_trails), 'euler_walks': len(eulers),
            'loop_insertion': checks, 'short_collisions': len(short_collisions),
            'long_collisions': len(long_collisions), 'all_inverse_checks_passed': True,
            'last_exit_bijection': last_exit_checks(size, eulers)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    rows = [row_by_subsets(size) for size in range(1, 5)]
    expected = [
        [1],
        [2, 6, 4],
        [6, 40, 118, 204, 288, 360, 216],
        [24, 270, 1536, 5916, 17976, 47016, 106992, 209232, 350784,
         490752, 580608, 580608, 331776],
    ]
    assert [result['row'] for result in rows] == expected
    result = {'schema_version': 1, 'method': 'exact integer subset dynamic programming and explicit trail bijections',
              'fixed_start': 0, 'rows': rows,
              'explicit_bijections': [trail_checks(size) for size in [2, 3]],
              'pruefer_bijections': [pruefer_checks(size) for size in range(2, 7)],
              'oeis_revision_16_rows_match': True,
              'all_three_formula_checks': True,
              'scope': 'Exact full rows and three formula checks for n=1..4; omitted-edge, loop-insertion and last-exit bijections for n=2,3; Pruefer bijections for n=2..6. Finite checks, not an all-input proof.'}
    arguments.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, separators=(',', ':')))


if __name__ == '__main__':
    main()
