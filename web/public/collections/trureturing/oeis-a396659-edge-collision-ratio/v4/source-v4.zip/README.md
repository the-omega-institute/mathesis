# Proof of Arkadeep Dutta's edge-collision ratio conjecture (OEIS A396659)

Haobo Ma — ChronoAI Pte Ltd, Singapore  
Wenlin Zhang — National University of Singapore; ChronoAI Pte Ltd, Singapore

1 November 2026. Revision 3. License: CC BY 4.0.

## Main source and result

`note.tex` is the sole main document; its bibliography is included directly.
There are no external figures, bibliography databases, or generated TeX inputs.
The distinguished-start, linearly ordered walk conventions are stated in the
note. For the entry [OEIS A396659, revision 16](https://oeis.org/A396659/internal),
the note proves all three statements in FORMULA:

- `T(n,n+1) = n!`, for every integer `n >= 1`;
- `T(n,n^2+1) = (n!)^n`, for every integer `n >= 1`;
- `T(n,n^2)/T(n,n^2+1) = (2n-1)/n`, for every integer `n >= 2`.

The proof is self-contained. The ratio's omitted-edge and loop-insertion
construction is also developed in
[CollisionPrefix.lean at d1876cfbbef8c13023311126691b180eefa69569](https://github.com/the-omega-institute/trureturing/blob/d1876cfbbef8c13023311126691b180eefa69569/D5/S3/Combinatorics/Graph/Walks/CollisionPrefix.lean).
In that source, `collision_ratio` proves the collision-count ratio and
`long_count_positive` proves positivity of the long collision count under
the formal walk hypotheses. The written proofs in Sections 2–5 establish
all three formulas; Section 5 proves the companion factorial formulas.

## Rebuild the PDF

The source archive contains `note.tex`, `metadata.json`, `LICENSE.txt`,
`verify.py`, `verification.json`, this guide, and `manifest.sha256`.
No engine, installation script, environment, or cache is included.

Compile `note.tex` directly with Tectonic 0.17.0:

```sh
sha256sum -c manifest.sha256
mkdir -p build
tectonic --untrusted --outdir build note.tex
python3 verify.py --output build/verification.json
cmp verification.json build/verification.json
```

Tectonic downloads missing TeX resources on its first run; subsequent builds
can reuse its cache. Alternatively, use an existing pdfLaTeX installation
with the packages listed at the top of `note.tex`:

```sh
mkdir -p build
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -output-directory=build note.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error -output-directory=build note.tex
```

The bibliography is inline, so no separate BibTeX run is required.
The Python checker requires Python 3 and its standard library only.

The selected PDF has four pages. Timestamp metadata can make PDF byte hashes
differ on a rebuild; compare extracted text and rendered pages for document
equivalence, rather than relying on PDF byte equality alone.

## Reproduce the finite checks

`verify.py` uses only Python's standard library, with exact integer arithmetic.
It independently counts trail prefixes by used-edge subset and endpoint.
All source rows for `n=1,2,3,4` match, and all three formulas are checked on
those rows. The last-two counts are `(6,4)`, `(360,216)`, and
`(580608,331776)` for `n=2,3,4` respectively.

Explicit enumeration for `n=2,3` checks the omitted-edge partition, both
directions of the return-trail and marked loop-insertion bijections, and
both directions of the last-exit-tree/local-order correspondence. Prüfer
encoding and decoding, distinct trees, and the rooted-parent enumeration
are independently compared for `n=2..6`.

These are finite checks, not an all-input proof. The all-`n` conclusions
follow from the written proofs, not from extrapolating the computed rows.
